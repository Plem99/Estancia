package servidor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
/**
 * @see http://www.jc-mouse.net/
 * @author mouse
 */
public class Servidor {

    /**
     * Puerto 
     */
    private final static int PORT = 5000;
    public static String strOutput;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        Process p; 
        try {
            //Socket de servidor para esperar peticiones de la red
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("Servidor> Servidor iniciado");    
            System.out.println("Servidor> En espera de cliente...");    
            //Socket de cliente
            Socket clientSocket;
            while(true){
                //en espera de conexion, si existe la acepta
                clientSocket = serverSocket.accept();
                //Para leer lo que envie el cliente
                BufferedReader input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                //para imprimir datos de salida                
                PrintStream output = new PrintStream(clientSocket.getOutputStream());
                //se lee peticion del cliente
                String request = input.readLine();
                System.out.println("Cliente> petición [" + request +  "]");
                //se procesa la peticion y se espera resultado
                strOutput = process(request);                
                //Se imprime en consola "servidor"
                System.out.println("Servidor> Resultado de petición");                    
                System.out.println(strOutput);
                System.out.println("Entre ");
                p = Runtime.getRuntime().exec("bash script.sh");
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                //pl " + strOutput
                p.waitFor();
                p.destroy();
                
                //se imprime en cliente
                output.flush();//vacia contenido
                output.println(strOutput);                
                //cierra conexion
                clientSocket.close();
                
                
            }    
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
        
        //============================================================
        
        
        /*
                //String s;
                Process p; 
                //Process p2;
                //Process p3;

                System.out.println("Entre");
                try {
                p = Runtime.getRuntime().exec("bash script.sh");
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                //pl " + strOutput
                p.waitFor();
                p.destroy();

                } catch (Exception e) {
                    }*/
                //============================================================
        
    }
    
    /**
     * procesa peticion del cliente y retorna resultado
     * @param request peticion del cliente
     * @return String
     */
    
    
    public static String process(String request){
        String result=""; 
        result = request;
        //result="echo pl " + request + " | nc localhost 1099";
        /*
        //frases
        String[] phrases = {
            "Si te he fallado te pido perdon."};
	ArrayList<String> phrasesList = new ArrayList<>();
	Collections.addAll(phrasesList, phrases);
        //libroslibro
        String[] books = {
            "Divina Comedia - Dante Alighieri"};
	ArrayList<String> booksList = new ArrayList<>();
	Collections.addAll(booksList, books);  */      
        /*
        if(request!=null) switch(request){
            case "meperdonas":
                Collections.shuffle(phrasesList);
                result = phrasesList.get(0);
                break;
            case "libro":
                Collections.shuffle(booksList);
                result = booksList.get(0);
                break;
            case "exit":                
                result = "bye";
                break;
            case "a2 off":                
                result = "a2";
                break;
            default:
                result = "La peticion no se puede resolver.";
                break;
                
        }
          */  
        return result;
    }
    
}